package com.ProjectLibrary.bibliotecauap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaUapApplicationTests {

	@Test
	void contextLoads() {
	}

}
